import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Wand2, AlertCircle } from 'lucide-react';
import { submitMood } from '@/lib/api/mood';
import { getErrorMessage } from '@/lib/utils/error';
import { useToast } from '@/hooks/use-toast';
import { useRetry } from '@/hooks/useRetry';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { MoodResultType } from '@/types/mood';

interface WelcomeSectionProps {
  username: string;
  onMoodSubmitted: (guidance: string) => void;
}

export function WelcomeSection({ username, onMoodSubmitted }: WelcomeSectionProps) {
  const [mood, setMood] = useState('');
  const [resultType, setResultType] = useState<MoodResultType | ''>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const webhookUrl = import.meta.env.VITE_MAKE_WEBHOOK_URL;
  const isMakeWebhookConfigured = Boolean(webhookUrl);

  const { execute: submitMoodWithRetry } = useRetry(
    async () => {
      if (!mood || !resultType) {
        throw new Error('Please fill in all fields');
      }
      return await submitMood({
        mood,
        resultType,
      });
    },
    { maxAttempts: 3 }
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isMakeWebhookConfigured) {
      toast({
        title: 'Configuration Error',
        description: 'Make.com webhook URL is not configured',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await submitMoodWithRetry();
      console.log('Mood submission response:', response);
      
      if (response?.guidance) {
        onMoodSubmitted(response.guidance);
        toast({
          title: 'Success',
          description: 'Your mood has been submitted',
        });
      } else {
        console.error('Missing guidance in response:', response);
        throw new Error('Invalid response from server');
      }
    } catch (error) {
      console.error('Submission error:', error);
      toast({
        title: 'Error',
        description: getErrorMessage(error),
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Rest of the component remains the same...