import { useEffect, useState, useRef } from 'react';

interface PageLoaderProps {
  children: React.ReactNode;
  fallback: React.ReactNode;
}

export function PageLoader({ children, fallback }: PageLoaderProps) {
  const [isLoading, setIsLoading] = useState(true);
  const mounted = useRef(false);

  useEffect(() => {
    mounted.current = true;
    
    // Use RAF for smooth transition
    const frame = requestAnimationFrame(() => {
      if (mounted.current) {
        setIsLoading(false);
      }
    });

    return () => {
      mounted.current = false;
      cancelAnimationFrame(frame);
    };
  }, []);

  return (
    <div className="min-h-screen">
      <div
        className={`fixed inset-0 z-50 transition-opacity duration-200 ${
          isLoading ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        {fallback}
      </div>
      <div
        className={`transition-opacity duration-200 ${
          isLoading ? 'opacity-0' : 'opacity-100'
        }`}
        aria-hidden={isLoading}
      >
        {children}
      </div>
    </div>
  );
}