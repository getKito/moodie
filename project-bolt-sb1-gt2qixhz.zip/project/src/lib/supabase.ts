import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types/supabase';

// Default values for development
const DEFAULT_URL = 'https://ufyhlafaspoemkcbvcui.supabase.co';
const DEFAULT_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVmeWhsYWZhc3BvZW1rY2J2Y3VpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzU0MzYwNzUsImV4cCI6MjA1MTAxMjA3NX0.SYJw210OeXnCbF6lBIKwJfQoB1E7jm5kngQ0W7n-8h4';

// Get environment variables or use defaults
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || DEFAULT_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || DEFAULT_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Using default Supabase credentials');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export async function checkSupabaseConnection() {
  try {
    const { error } = await supabase.from('profiles').select('count');
    return !error;
  } catch (error) {
    console.error('Supabase connection error:', error);
    return false;
  }
}