import { Home, Database, Settings } from 'lucide-react';

export const menuItems = [
  { icon: Home, label: 'Home', href: '/home' },
  { icon: Database, label: 'Database', href: '/database' },
  { icon: Settings, label: 'Settings', href: '/settings' },
];