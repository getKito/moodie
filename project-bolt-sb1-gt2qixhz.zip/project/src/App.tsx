import { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { PageTransition } from '@/components/routing/PageTransition';
import { SkeletonLoader } from '@/components/loading/SkeletonLoader';
import DashboardLayout from '@/components/layouts/DashboardLayout';
import Landing from '@/pages/Landing';

// Lazy load pages with error boundaries
const Home = lazy(() => import('@/pages/Home'));
const Auth = lazy(() => import('@/pages/Auth'));
const Donate = lazy(() => import('@/pages/Donate'));
const Database = lazy(() => import('@/pages/Database'));
const Settings = lazy(() => import('@/pages/Settings'));

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<Landing />} />
        
        <Route path="/auth" element={
          <Suspense fallback={<SkeletonLoader type="home" />}>
            <PageTransition>
              <Auth />
            </PageTransition>
          </Suspense>
        } />
        
        <Route element={
          <ProtectedRoute>
            <DashboardLayout />
          </ProtectedRoute>
        }>
          <Route path="/home" element={
            <Suspense fallback={<SkeletonLoader type="home" />}>
              <PageTransition>
                <Home />
              </PageTransition>
            </Suspense>
          } />
          <Route path="/donate" element={
            <Suspense fallback={<SkeletonLoader type="home" />}>
              <PageTransition>
                <Donate />
              </PageTransition>
            </Suspense>
          } />
          <Route path="/database" element={
            <Suspense fallback={<SkeletonLoader type="database" />}>
              <PageTransition>
                <Database />
              </PageTransition>
            </Suspense>
          } />
          <Route path="/settings" element={
            <Suspense fallback={<SkeletonLoader type="home" />}>
              <PageTransition>
                <Settings />
              </PageTransition>
            </Suspense>
          } />
        </Route>
      </Routes>
    </AuthProvider>
  );
}