import { useState } from 'react';
import { submitMood } from '@/lib/api/mood';
import { useToast } from '@/hooks/use-toast';
import { getErrorMessage } from '@/lib/utils/error';
import type { MoodSubmission, MoodResponse } from '@/types/mood';

export function useMoodSubmission() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const submit = async (data: MoodSubmission): Promise<MoodResponse | null> => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await submitMood(data);
      toast({
        title: 'Success',
        description: 'Your mood has been submitted',
      });
      return response;
    } catch (err) {
      const message = getErrorMessage(err);
      setError(message);
      toast({
        title: 'Error',
        description: message,
        variant: 'destructive',
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  return { submit, loading, error };
}