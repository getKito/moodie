import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useProfile } from '@/hooks/useProfile';
import { WelcomeSection } from './components/WelcomeSection';
import { MoodDisplay } from './components/MoodDisplay';
import { motion } from 'framer-motion';

export function Home() {
  const [guidance, setGuidance] = useState('');
  const { user } = useAuth();
  const { profile } = useProfile(user?.id || '');
  
  const currentDate = new Date();
  const month = currentDate.toLocaleString('default', { month: 'long' }).toUpperCase();
  const day = currentDate.getDate().toString().padStart(2, '0');

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.2 }}
      className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 lg:py-8"
    >
      <div className="grid lg:grid-cols-2 gap-8">
        <WelcomeSection 
          username={profile?.display_name || 'User'} 
          onMoodSubmitted={setGuidance} 
        />
        <MoodDisplay 
          month={month} 
          day={day} 
          guidance={guidance}
        />
      </div>
    </motion.div>
  );
}