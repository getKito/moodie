import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Wand2, AlertCircle } from 'lucide-react';
import { useMoodSubmission } from '../hooks/useMoodSubmission';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { MoodResultType } from '@/types/mood';

interface WelcomeSectionProps {
  username: string;
  onMoodSubmitted: (guidance: string) => void;
}

export function WelcomeSection({ username, onMoodSubmitted }: WelcomeSectionProps) {
  const [mood, setMood] = useState('');
  const [resultType, setResultType] = useState<MoodResultType | ''>('');
  const { submit, loading, error } = useMoodSubmission();

  const webhookUrl = import.meta.env.VITE_MAKE_WEBHOOK_URL;
  const isMakeWebhookConfigured = Boolean(webhookUrl);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!mood || !resultType) return;
    
    const response = await submit({ mood, resultType });
    if (response?.guidance) {
      onMoodSubmitted(response.guidance);
    }
  };

  return (
    <div className="space-y-8 w-full max-w-xl mx-auto lg:mx-0">
      {/* Rest of the component JSX remains the same */}
    </div>
  );
}